# Zipped skill

From a .zip in ~/.helm/plugins.
